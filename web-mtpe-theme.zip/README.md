## Wordpress Theme Web MTPE

Este repositorio contiene el código fuente del tema de wordpress
desarrollado para el Ministerio del trabajo y promoción del empleo
de Perú.

El tema ha sido desarrollado junto con la versión 5.8 de Wordpress.

Para instalar el tema se debe clonar el repositorio dentro de la carpeta ```wp-content/themes```
donde está instalado Wordpress.

El tema ha sido desarrollado por el Equipo de [Mapeo](https://web.mapeo.pe)