<div class="col-4 d-flex justify-content-center">
  <button id="btnPrint" onclick="javascript:window.print()" class="btn-utils">
    <span class="icon-utils icon--gob-44 material-icons">print</span>
    <span>Imprimir</span>
  </button>
</div>
<div class="col-4 d-flex justify-content-center">
  <button type="button" id="btnShare" class="btn-utils ss-btn-share">
    <span class="icon-utils icon--gob-44 material-icons">share</span>
    <span>Compartir</span>
  </button>
</div>
<div class="col-4 d-flex justify-content-center">
  <button type="button" id="btnSave" class="btn-utils">
    <span class="icon-utils icon--gob-44 material-icons">bookmark_border</span>
    <span>Guardar</span>
  </button>
</div>