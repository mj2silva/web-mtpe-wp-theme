<?php get_header(); ?>

<main id="main" class="container" style="min-height: 50vh">
  <div class="container mt-20 mb-24 page_errors">
    <div class="text-center mx-auto w-9/12 md:w-full">
    <h1 class="leading-6 z-10 mt-20 md:-mt-12 mb-5 text-gray-900 text-xl md:text-3xl text-center">
    Lo sentimos. La página que buscas no existe.
    </h1>
    <p class="md:leading-6 text-gray-900 md:text-xl text-base">Puede que hayas escrito mal la dirección, que la hayan cambiado o eliminado.</p>
    </div>
  </div>
<h1 class="text-center">
  

</h1>

</main>

<?php get_footer(); ?>